package practica2;
/**
 *
 * @author luisGonzalez
 */
public final class Practica2 {
    
    //metodo que dara inicio al juego 
    public static void main(String[] args) {
        MenuPrincipal inicio = new MenuPrincipal();
        inicio.setVisible(true);
    }
    
}
